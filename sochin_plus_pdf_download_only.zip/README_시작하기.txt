소친플러스 PDF 연결 수정 버전

1. ZIP 압축을 풀고 index.html을 실행하세요.
2. 캠퍼스맵 열기: campus-map-viewer.html에서 보내주신 원본 PDF를 보여줍니다.
3. PDF 다운로드: assets/서경대 캠퍼스맵.pdf 원본 파일을 내려받습니다.
4. 일부 휴대폰 브라우저는 PDF 미리보기를 지원하지 않으므로 뷰어 화면의 원본 PDF 직접 열기/다운로드 버튼을 사용하세요.
5. index.html, campus-map-viewer.html, assets 폴더를 함께 유지하거나 웹 호스팅에 올리세요.
